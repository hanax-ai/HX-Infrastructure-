# gateway/src/main.py
from .app import build_app

app = build_app()
